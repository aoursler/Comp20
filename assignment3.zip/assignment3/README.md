1. All aspects of this assignment have been implemented. No aspects of this
   assignment have not been implemented
2. I used stackoverflow and the heroku tutorial for this lab. In addition I
   recieved help from many TAs and from Ming.
3. I spend aprozimately 20 hour on this assignment.